function retval = Objectivefunction_(x)
% example 1
retval = 4*x(1)^2+3*x(2)^2-4*x(1)*x(2)+x(1);
% objective function is 2*x(1)^3+4*x(1)*x(2)^3-10*x(1)*x(2)+x(2)^2
